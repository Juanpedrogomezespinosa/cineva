  </main>
  <footer>
    <p>&copy; 2025 - <?php echo APP_NAME; ?></p>
  </footer>
</body>
</html>
