<?php
// Configuración general del proyecto

// Mostrar errores (activar solo en entorno de desarrollo, desactivar en producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Opciones de seguridad para la sesión (deben ir antes de iniciar la sesión)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}

// Rutas físicas importantes dentro del servidor
define('BASE_PATH', __DIR__ . '/../');
define('IMG_PATH', BASE_PATH . 'img/');
define('PORTADAS_PATH', IMG_PATH . 'portadas/');
define('AVATARS_PATH', IMG_PATH . 'avatars/');

// Configuración de la aplicación
define('APP_NAME', 'Cineva');
define('APP_URL', 'https://cineva.42web.io/'); // Dominio que indicaste en InfinityFree
?>
