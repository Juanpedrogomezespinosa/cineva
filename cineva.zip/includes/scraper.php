<?php
// Este archivo se usará en el futuro para scrapear o usar APIs de plataformas de streaming

function obtenerDisponibilidad($titulo) {
    // TODO: implementar scraping o API
    return "Disponible en: Netflix (ejemplo)";
}
?>
