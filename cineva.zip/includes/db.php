<?php
class Database {
    // Datos de conexión al servidor MySQL de InfinityFree
    private string $host = 'sql202.infinityfree.com'; // Si en tu panel aparece otro host, cámbialo aquí
    private string $dbName = 'cineva';               // Nombre de la base de datos que indicaste
    private string $username = 'if0_40018009';       // Usuario de la base de datos
    private string $password = 'cGR8vbNruf';         // Contraseña que indicaste
    private PDO $connection;

    public function __construct() {
        try {
            $dataSourceName = "mysql:host={$this->host};dbname={$this->dbName};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $this->connection = new PDO($dataSourceName, $this->username, $this->password, $options);
        } catch (PDOException $exception) {
            // Mensaje claro si hay fallo de conexión
            die('Error de conexión a la base de datos: ' . $exception->getMessage());
        }
    }

    public function getConnection(): PDO {
        return $this->connection;
    }
}
?>
